import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RestaurantManagementSystem extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> accountTypeComboBox;
    private JFrame cartFrame;
    private JFrame paymentFrame;
    private String username;
    private JPanel menuPanel;

    private List<String> selectedItems = new ArrayList<>();
    private Map<String, Integer> inventory = new HashMap<>(); 


    

    public RestaurantManagementSystem() {
        
        cartFrame = new JFrame();
        paymentFrame = new JFrame();
        menuPanel = createMenuPanel();
        JButton viewInventoryButton = new JButton("View Inventory");


        viewInventoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openViewInventoryPage();
            }
        });

        setTitle("Restaurant Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        
        JLabel welcomeLabel = new JLabel("Welcome to Capital Grill");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(Color.BLUE);

        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel accountTypeLabel = new JLabel("Account Type:");
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        String[] accountTypes = {"Admin", "Customer"};
        accountTypeComboBox = new JComboBox<>(accountTypes);
        JButton loginButton = new JButton("Login");

        
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(welcomeLabel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(usernameLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(passwordLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(accountTypeLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        add(accountTypeComboBox, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        add(loginButton, gbc);

        
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                String username = usernameField.getText();
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);
                String accountType = (String) accountTypeComboBox.getSelectedItem();

                
                if ("Admin".equals(accountType)) {
                    openAdminDashboard(username);
                } else if ("Customer".equals(accountType)) {
                    openCustomerDashboard(username);
                }
            }
        });
    }

    private void openAdminDashboard(String username) {
        
        dispose();
    
        
        JFrame adminDashboardFrame = new JFrame("Admin Dashboard - " + username);
        adminDashboardFrame.setSize(800, 600);
        adminDashboardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        adminDashboardFrame.setLocationRelativeTo(null);
    
        
        JLabel welcomeLabel = new JLabel("Welcome, Admin " + username + "!");
        
        JLabel roleLabel = new JLabel("Role: Administrator");
    
        JButton viewOrdersButton = new JButton("View Orders");
        JButton updateMenuButton = new JButton("Update Menu");
        JButton viewFeedbackButton = new JButton("View Feedback");
        JButton viewLogisticsButton = new JButton("View Logistics");
        JButton viewInventoryButton = new JButton("View Inventory"); 
    
        
        adminDashboardFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
    
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        adminDashboardFrame.add(welcomeLabel, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        adminDashboardFrame.add(roleLabel, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        adminDashboardFrame.add(viewOrdersButton, gbc);
    
        gbc.gridx = 1;
        gbc.gridy = 3;
        adminDashboardFrame.add(updateMenuButton, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 4;
        adminDashboardFrame.add(viewFeedbackButton, gbc);
    
        gbc.gridx = 1;
        gbc.gridy = 4;
        adminDashboardFrame.add(viewLogisticsButton, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 5;
        adminDashboardFrame.add(viewInventoryButton, gbc); 
    
        
        viewOrdersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openViewOrdersPage(username);
            }
        });
    
        updateMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openUpdateMenuPage(username);
            }
        });
    
        viewFeedbackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openViewFeedbackPage(username);
            }
        });
    
        viewLogisticsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openViewLogisticsPage(username);
            }
        });
    
        viewInventoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openViewInventoryPage();;
            }
        });
    
        
        adminDashboardFrame.setVisible(true);
    }
    
   
    
    


private void openViewInventoryPage() {
    JFrame viewInventoryFrame = new JFrame("View Inventory");
    viewInventoryFrame.setSize(800, 600);
    viewInventoryFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    viewInventoryFrame.setLocationRelativeTo(null);

    JLabel inventoryLabel = new JLabel("Inventory Details:");
    JTextArea inventoryTextArea = new JTextArea();
    inventoryTextArea.setEditable(false);
    JScrollPane inventoryScrollPane = new JScrollPane(inventoryTextArea);

    JButton addItemButton = new JButton("Add Item");
    JButton updateButton = new JButton("Update");

    viewInventoryFrame.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);

    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.anchor = GridBagConstraints.WEST;
    viewInventoryFrame.add(inventoryLabel, gbc);

    gbc.gridx = 0;
    gbc.gridy = 1;
    viewInventoryFrame.add(inventoryScrollPane, gbc);

    gbc.gridx = 0;
    gbc.gridy = 2;
    viewInventoryFrame.add(addItemButton, gbc);

    
    
    

    
    inventory.put("Flour", 10);
    inventory.put("Sugar", 20);
    inventory.put("Eggs", 50);
    inventory.put("Milk", 20);
    inventory.put("Butter", 88);
    inventory.put("Salt", 60);
    inventory.put("Chicken", 25);

    
    updateInventoryTextArea(inventoryTextArea);

    addItemButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            openAddItemDialog(username);  
            updateInventoryTextArea(inventoryTextArea);
        }
    });

    
    
    
    
    
    

    viewInventoryFrame.setVisible(true);
}

private void openAddItemDialog(String username) {
    JFrame addItemDialog = new JFrame("Add Item - " + username);
    addItemDialog.setSize(400, 200);
    addItemDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    addItemDialog.setLocationRelativeTo(null);

    JLabel itemNameLabel = new JLabel("Item Name:");
    JTextField itemNameField = new JTextField(20);
    JLabel quantityLabel = new JLabel("Quantity:");
    JTextField quantityField = new JTextField(5);

    JButton addButton = new JButton("Add");

    addItemDialog.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);

    gbc.gridx = 0;
    gbc.gridy = 0;
    addItemDialog.add(itemNameLabel, gbc);

    gbc.gridx = 1;
    gbc.gridy = 0;
    addItemDialog.add(itemNameField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 1;
    addItemDialog.add(quantityLabel, gbc);

    gbc.gridx = 1;
    gbc.gridy = 1;
    addItemDialog.add(quantityField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 2;
    gbc.gridwidth = 2;
    addItemDialog.add(addButton, gbc);

    addButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String itemName = itemNameField.getText();
            int quantity = Integer.parseInt(quantityField.getText());

            
            inventory.put(itemName, quantity);

            
            addItemDialog.dispose();
        }
    });

    addItemDialog.setVisible(true);
}

private void updateInventoryTextArea(JTextArea inventoryTextArea) {
    inventoryTextArea.setText("Inventory:\n");
    for (Map.Entry<String, Integer> entry : inventory.entrySet()) {
        inventoryTextArea.append(entry.getKey() + ": " + entry.getValue() + "\n");
    }
}




    
    private void openViewOrdersPage(String username) {
        
        JFrame viewOrdersFrame = new JFrame("View Orders - " + username);
        
        viewOrdersFrame.setSize(600, 400);
        viewOrdersFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        viewOrdersFrame.setLocationRelativeTo(null);
        viewOrdersFrame.setVisible(true);
    }
    
    private void openUpdateMenuPage(String username) {
        
        JFrame updateMenuFrame = new JFrame("Update Menu - " + username);
        
        updateMenuFrame.setSize(600, 400);
        updateMenuFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        updateMenuFrame.setLocationRelativeTo(null);
        updateMenuFrame.setVisible(true);
    }
    
    private void openViewFeedbackPage(String username) {
        
        JFrame viewFeedbackFrame = new JFrame("View Feedback - " + username);
        
        viewFeedbackFrame.setSize(600, 400);
        viewFeedbackFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        viewFeedbackFrame.setLocationRelativeTo(null);
        viewFeedbackFrame.setVisible(true);
    }
    

    private void openViewLogisticsPage(String username) {
        
        JFrame viewLogisticsFrame = new JFrame("View Logistics - " + username);
        viewLogisticsFrame.setSize(800, 600);
        viewLogisticsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        viewLogisticsFrame.setLocationRelativeTo(null);
    
        
        JLabel logisticsLabel = new JLabel("Logistics Details:");
        JTextArea logisticsTextArea = new JTextArea();
        logisticsTextArea.setEditable(false);
        JScrollPane logisticsScrollPane = new JScrollPane(logisticsTextArea);
    
        JButton viewSupplierButton = new JButton("Supplier Details");
    
    
    
        
        viewLogisticsFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
    
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        viewLogisticsFrame.add(logisticsLabel, gbc);
    
   
    
        gbc.gridx = 0;
        gbc.gridy = 2;
        viewLogisticsFrame.add(viewSupplierButton, gbc);
    
        
        viewSupplierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openSupplierDetailsPage(username);
            }
        });
    
        
        viewLogisticsFrame.setVisible(true);
    
        
    }
    
    
    private void openSupplierDetailsPage(String username) {
        
        JFrame supplierDetailsFrame = new JFrame("Supplier Details - " + username);
        supplierDetailsFrame.setSize(800, 600);
        supplierDetailsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        supplierDetailsFrame.setLocationRelativeTo(null);
    
        
        JLabel supplierDetailsLabel = new JLabel("Supplier Details:");
        JTextArea supplierDetailsTextArea = new JTextArea();
        supplierDetailsTextArea.setEditable(false);
        JScrollPane supplierDetailsScrollPane = new JScrollPane(supplierDetailsTextArea);
    
        JButton viewVehicleButton = new JButton("View Vehicle Details");
        JButton viewWarehouseButton = new JButton("View Warehouse Details");
    
        
        String supplierDetailsInfo = "Supplier Name: Supplier ABC\n" +
                "Contact: 123-456-7890\n" +
                "Address: 123 Main St";
    
        
        supplierDetailsFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbcSupplier = new GridBagConstraints();
        gbcSupplier.insets = new Insets(10, 10, 10, 10);
    
        
        gbcSupplier.gridx = 0;
        gbcSupplier.gridy = 0;
        gbcSupplier.anchor = GridBagConstraints.WEST;
        supplierDetailsFrame.add(supplierDetailsLabel, gbcSupplier);
    
        gbcSupplier.gridx = 0;
        gbcSupplier.gridy = 1;
        supplierDetailsFrame.add(supplierDetailsScrollPane, gbcSupplier);
    
        gbcSupplier.gridx = 0;
        gbcSupplier.gridy = 2;
        supplierDetailsFrame.add(viewVehicleButton, gbcSupplier);
    
        gbcSupplier.gridx = 0;
        gbcSupplier.gridy = 3;
        supplierDetailsFrame.add(viewWarehouseButton, gbcSupplier);
    
        
        viewVehicleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openVehicleDetailsPage(username);
            }
        });
    
        viewWarehouseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openWarehouseDetailsPage(username);
            }
        });
    
        
        supplierDetailsFrame.setVisible(true);
    
        
        supplierDetailsTextArea.setText(supplierDetailsInfo);
    }
    
    
    private void openVehicleDetailsPage(String username) {
        
        JFrame vehicleDetailsFrame = new JFrame("Vehicle Details - " + username);
        
        vehicleDetailsFrame.setSize(600, 400);
        vehicleDetailsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        vehicleDetailsFrame.setLocationRelativeTo(null);
        vehicleDetailsFrame.setVisible(true);
    }
    
    
    private void openWarehouseDetailsPage(String username) {
        
        JFrame warehouseDetailsFrame = new JFrame("Warehouse Details - " + username);
        
        warehouseDetailsFrame.setSize(600, 400);
        warehouseDetailsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        warehouseDetailsFrame.setLocationRelativeTo(null);
        warehouseDetailsFrame.setVisible(true);
    }
        
   


    
    

    

    private void openCustomerDashboard(String username) {
        
        dispose();

        
        JFrame customerDashboardFrame = new JFrame("Customer Dashboard - " + username);
        customerDashboardFrame.setSize(800, 600);
        customerDashboardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        customerDashboardFrame.setLocationRelativeTo(null);

        
        JLabel welcomeLabel = new JLabel("Welcome, " + username + "!");
        JButton dineInButton = new JButton("Dine In");
        JButton orderOutButton = new JButton("Order Out");

        
        customerDashboardFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        customerDashboardFrame.add(welcomeLabel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        customerDashboardFrame.add(dineInButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        customerDashboardFrame.add(orderOutButton, gbc);

        
        dineInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                openMenuPage("Dine In", username);
            }
        });

        orderOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                openMenuPage("Order Out", username);
            }
        });

        
        customerDashboardFrame.setVisible(true);
    }

    private void openMenuPage(String orderType, String username) {
        
        dispose();

        
        JFrame menuFrame = new JFrame("Menu - " + orderType);
        menuFrame.setSize(800, 600);
        menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menuFrame.setLocationRelativeTo(null);

        
        JPanel menuPanel = createMenuPanel();

        
        JButton addToCartButton = new JButton("Add to Cart");
        addToCartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                List<String> selectedItems = getSelectedItems(menuPanel);
                openCartPage(username, selectedItems, "Dine In".equals(orderType));
            }
        });

        
        menuFrame.setLayout(new BorderLayout());

        
        menuFrame.add(new JScrollPane(menuPanel), BorderLayout.CENTER);
        menuFrame.add(addToCartButton, BorderLayout.SOUTH);

        
        menuFrame.setVisible(true);
    }

    private JPanel createMenuPanel() {
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(0, 1));
    
        // Set the prices for each menu item
        menuPanel.add(createMenuItem("Margherita Pizza - $18", 18.0));
        menuPanel.add(createMenuItem("Caesar Salad - $15", 15.0));
        menuPanel.add(createMenuItem("Chicken Caesar Wrap - $10", 10.0));
        menuPanel.add(createMenuItem("Shrimp Scampi - $22", 22.0));
        menuPanel.add(createMenuItem("Club Sandwich - $15", 15.0));
    
        return menuPanel;
    }

    private JPanel createMenuItem(String itemName, double itemPrice) {
        JPanel menuItemPanel = new JPanel();
        JCheckBox checkBox = new JCheckBox(itemName);
        checkBox.putClientProperty("itemPrice", itemPrice); // Set the price as a client property
        menuItemPanel.add(checkBox);
        return menuItemPanel;
    }

    private List<String> getSelectedItems(JPanel menuPanel) {
        List<String> selectedItems = new ArrayList<>();
        Component[] components = menuPanel.getComponents();
        for (Component component : components) {
            if (component instanceof JPanel) {
                JPanel menuItemPanel = (JPanel) component;
                Component[] innerComponents = menuItemPanel.getComponents();
                for (Component innerComponent : innerComponents) {
                    if (innerComponent instanceof JCheckBox) {
                        JCheckBox checkBox = (JCheckBox) innerComponent;
                        if (checkBox.isSelected()) {
                            selectedItems.add(checkBox.getText());
                        }
                    }
                }
            }
        }
        return selectedItems;
    }

    
private void openCartPage(String username, List<String> selectedItems, boolean dineIn) {
    
    dispose();

    // double cartTotal = calculateTotal(selectedItems);
    
    cartFrame.setTitle("Cart - " + username);
    cartFrame.setSize(800, 600);
    cartFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    cartFrame.setLocationRelativeTo(null);

    
    JLabel cartLabel = new JLabel("Shopping Cart:");
    JTextArea cartTextArea = new JTextArea();
    cartTextArea.setEditable(false);
    JScrollPane cartScrollPane = new JScrollPane(cartTextArea);

    JLabel deliveryLabel = new JLabel("Delivery Address:");
    JTextField deliveryAddressField = new JTextField(20);

    JLabel contactLabel = new JLabel("Contact Details:");
    JTextField contactDetailsField = new JTextField(20);

    
    double cartTotal = calculateTotal(selectedItems, menuPanel);

    
    JLabel totalLabel = new JLabel(String.format("Total: $%.2f", cartTotal));

    JButton proceedToPaymentButton = new JButton("Proceed to Payment");
    proceedToPaymentButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            
            openPaymentPage(username, selectedItems, dineIn, deliveryAddressField.getText(), contactDetailsField.getText(), cartTotal);
        }
    });

    
    cartFrame.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);

    
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.anchor = GridBagConstraints.WEST;
    cartFrame.add(cartLabel, gbc);

    gbc.gridx = 0;
    gbc.gridy = 1;
    cartFrame.add(cartScrollPane, gbc);

    
    if (!dineIn) {
        gbc.gridx = 0;
        gbc.gridy = 2;
        cartFrame.add(deliveryLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        cartFrame.add(deliveryAddressField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        cartFrame.add(contactLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        cartFrame.add(contactDetailsField, gbc);
    }

    gbc.gridx = 0;
    gbc.gridy = dineIn ? 2 : 4; 
    cartFrame.add(totalLabel, gbc); 

    gbc.gridx = 1;
    gbc.gridy = dineIn ? 2 : 4; 
    cartFrame.add(proceedToPaymentButton, gbc);

    
    cartFrame.setVisible(true);

    
    updateCartTextArea(cartTextArea, selectedItems);
}


private void openPaymentPage(String username, List<String> selectedItems, boolean dineIn, String deliveryAddress, String contactDetails, double cartTotal) {
    
    cartFrame.dispose();

    
    paymentFrame.setTitle("Payment - " + username);
    paymentFrame.setSize(800, 600);
    paymentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    paymentFrame.setLocationRelativeTo(null);

    
    JLabel paymentLabel = new JLabel("Payment Options:");
    JRadioButton cardRadioButton = new JRadioButton("Card");
    JRadioButton cashRadioButton = new JRadioButton("Cash");
    JRadioButton applePayRadioButton = new JRadioButton("Apple Pay");

    ButtonGroup paymentOptionsGroup = new ButtonGroup();
    paymentOptionsGroup.add(cardRadioButton);
    paymentOptionsGroup.add(cashRadioButton);
    paymentOptionsGroup.add(applePayRadioButton);

    JTextField cardNumberField = new JTextField(20);
    JTextField cvvField = new JTextField(3);

    
    JLabel totalLabel = new JLabel(String.format("Total: $%.2f", cartTotal));

    JButton payButton = new JButton("Pay");
    payButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            
            if (cardRadioButton.isSelected()) {
                
                String cardNumber = cardNumberField.getText();
                String cvv = cvvField.getText();
                
                openDeliveryPage(username, dineIn, deliveryAddress, contactDetails, cartTotal);
            } else if (cashRadioButton.isSelected()) {
                
                openDeliveryPage(username, dineIn, deliveryAddress, contactDetails, cartTotal);
            } else if (applePayRadioButton.isSelected()) {
                
                openDeliveryPage(username, dineIn, deliveryAddress, contactDetails, cartTotal);
            } else {
                
                JOptionPane.showMessageDialog(paymentFrame, "Please select a payment option!");
            }
        }
    });

    
    paymentFrame.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);

    
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.anchor = GridBagConstraints.WEST;
    paymentFrame.add(paymentLabel, gbc);

    gbc.gridx = 0;
    gbc.gridy = 1;
    paymentFrame.add(cardRadioButton, gbc);

    gbc.gridx = 0;
    gbc.gridy = 2;
    paymentFrame.add(cashRadioButton, gbc);

    gbc.gridx = 0;
    gbc.gridy = 3;
    paymentFrame.add(applePayRadioButton, gbc);

    gbc.gridx = 0;
    gbc.gridy = 4;
    paymentFrame.add(new JLabel("Card Number:"), gbc);

    gbc.gridx = 0;
    gbc.gridy = 5;
    paymentFrame.add(cardNumberField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 6;
    paymentFrame.add(new JLabel("CVV:"), gbc);

    gbc.gridx = 0;
    gbc.gridy = 7;
    paymentFrame.add(cvvField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 8;
    paymentFrame.add(totalLabel, gbc); 

    gbc.gridx = 0;
    gbc.gridy = 9;
    paymentFrame.add(payButton, gbc);

    
    paymentFrame.setVisible(true);
}

    
    private void openDeliveryPage(String username, boolean dineIn, String deliveryAddress, String contactDetails, double cartTotal) {
        
        paymentFrame.dispose();
    
        
        JFrame deliveryFrame = new JFrame("Delivery - " + username);
        deliveryFrame.setSize(800, 600);
        deliveryFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        deliveryFrame.setLocationRelativeTo(null);
    
        
        JLabel deliveryLabel = new JLabel("Delivery Details:");
        JLabel addressLabel = new JLabel("Delivery Address:");
        JLabel contactLabel = new JLabel("Contact Details:");
        JLabel totalLabel = new JLabel("Cart Total:");
        JLabel paymentStatusLabel = new JLabel("Payment Status:");
    
        JTextField addressField;
        JTextField contactField;
    
        
        if (dineIn) {
            addressField = new JTextField("Dine In");
            contactField = new JTextField("N/A");
        } else {
            addressField = new JTextField(deliveryAddress);
            contactField = new JTextField(contactDetails);
        }
    
        JTextField totalField = new JTextField("$" + cartTotal);
        JTextField paymentStatusField = new JTextField("Payment Done");
    
        JButton finishButton = new JButton("Finish");
        finishButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                System.exit(0);
            }
        });
    
        
        deliveryFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
    
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        deliveryFrame.add(deliveryLabel, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 1;
        deliveryFrame.add(addressLabel, gbc);
    
        gbc.gridx = 1;
        gbc.gridy = 1;
        deliveryFrame.add(addressField, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 2;
        deliveryFrame.add(contactLabel, gbc);
    
        gbc.gridx = 1;
        gbc.gridy = 2;
        deliveryFrame.add(contactField, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 3;
        deliveryFrame.add(totalLabel, gbc);
    
        gbc.gridx = 1;
        gbc.gridy = 3;
        deliveryFrame.add(totalField, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 4;
        deliveryFrame.add(paymentStatusLabel, gbc);
    
        gbc.gridx = 1;
        gbc.gridy = 4;
        deliveryFrame.add(paymentStatusField, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 5;
        deliveryFrame.add(finishButton, gbc);
    
        
        deliveryFrame.setVisible(true);
    }
    
    
    private double calculateTotal(List<String> selectedItems, JPanel menuPanel) {
        double total = 0.0;
    
        for (String selectedItem : selectedItems) {
            // Pass the menuPanel to getItemPrice
            double itemPrice = getItemPrice(selectedItem, menuPanel);
            total += itemPrice;
        }
    
        return total;
    }
    
    
    

    
    private void updateCartTextArea(JTextArea cartTextArea, List<String> selectedItems) {
        cartTextArea.setText("");
        for (String item : selectedItems) {
            cartTextArea.append(item + "\n");
        }
    }

    private double getItemPrice(String itemName, JPanel menuPanel) {
        Component[] components = menuPanel.getComponents();
        for (Component component : components) {
            if (component instanceof JPanel) {
                JPanel menuItemPanel = (JPanel) component;
                Component[] innerComponents = menuItemPanel.getComponents();
                for (Component innerComponent : innerComponents) {
                    if (innerComponent instanceof JCheckBox) {
                        JCheckBox checkBox = (JCheckBox) innerComponent;
                        if (checkBox.isSelected() && itemName.equals(checkBox.getText())) {
                            // Retrieve the item price from the client property
                            return (double) checkBox.getClientProperty("itemPrice");
                        }
                    }
                }
            }
        }
        return 0.0;
    }
    
    
    
    

    

    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RestaurantManagementSystem().setVisible(true);
            }
        });
    }
}
