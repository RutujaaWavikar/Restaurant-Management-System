INSERT INTO UserAccount (AccountID, AccountPassword, AccountName, UserName, UserDateOfBirth, UserContactNumber, UserAddress, UserEmail, AccountType)
VALUES 
(00001001, 'Viraj Gupta', 'Password123', 'Vgupta', '1997-01-20', '+15551234567', '123 Main St, Boston', 'vgupta@gmail.com', 'Admin'),
(00001002, 'Rituja Wavikar', 'Pass1234', 'RitujaW', '1998-10-10', '+15559876543', '999 Huntington Avenue, Boston', 'rw@gmail.com', 'Admin'),
(00001003, 'Yashwant Dubey', 'Pass@1234', 'YashDubey', '1997-03-26', '+15552345678', '22 South St, Boston', 'yashd@gmail.com', 'Admin'),
(00001004, 'Ziyi Yin', 'Password@1234', 'MaxZY', '1999-06-18', '+865553456789', '796 Pleasant St, Boston', 'ziyiyin641@gmail.com', 'Admin'),
(00001005, 'Aarav Patel', 'AaravPass123', 'AaravP', '1995-08-15', '9876543210', '456 Oak St, New York', 'aarav.patel@gmail.com', 'Customer'),
(00001006, 'Sophia Johnson', 'SophiaPass1', 'SophiaJ', '1996-05-22', '1234567890', '789 Maple St, Los Angeles', 'sophia.johnson@gmail.com', 'Customer'),
(00001007, 'Arya Singh', 'Arya@123', 'AryaS', '1998-12-10', '8765432109', '321 Pine St, Chicago', 'arya.singh@gmail.com', 'Admin'),
(00001008, 'Liam Smith', 'LiamSmith123', 'LiamS', '1994-04-05', '2345678901', '654 Elm St, San Francisco', 'liam.smith@gmail.com', 'Customer'),
(00001009, 'Aaradhya Sharma', 'Aaradhya@123', 'AaradhyaS', '1997-09-30', '7890123456', '987 Cedar St, Houston', 'aaradhya.sharma@gmail.com', 'Customer'),
(00001010, 'Mia Anderson', 'MiaPass123', 'MiaA', '1996-02-14', '2109876543', '147 Redwood St, Miami', 'mia.anderson@gmail.com', 'Customer'),
(00001011, 'Aryan Kapoor', 'AryanK@123', 'AryanK', '1999-07-08', '5678901234', '369 Oak St, Atlanta', 'aryan.kapoor@gmail.com', 'Admin'),
(00001012, 'Olivia Brown', 'OliviaPass1', 'OliviaB', '1995-11-20', '4321098765', '258 Pine St, Seattle', 'olivia.brown@gmail.com', 'Customer'),
(00001013, 'Rohan Verma', 'Rohan@123', 'RohanV', '1998-06-25', '8765432101', '753 Maple St, Dallas', 'rohan.verma@gmail.com', 'Admin'),
(00001014, 'Emma Taylor', 'EmmaTaylor123', 'EmmaT', '1997-03-15', '1098765432', '951 Cedar St, Denver', 'emma.taylor@gmail.com', 'Customer'),
(00001015, 'Aarav Kumar', 'Kumar@123', 'AaravK', '1996-09-12', '7654321098', '246 Redwood St, Phoenix', 'aarav.kumar@gmail.com', 'Admin'),
(00001016, 'Ava White', 'AvaPass123', 'AvaW', '1995-04-28', '9876543210', '753 Pine St, Detroit', 'ava.white@gmail.com', 'Customer'),
(00001017, 'Arjun Reddy', 'Arjun@123', 'ArjunR', '1998-01-03', '8765432109', '852 Oak St, Minneapolis', 'arjun.reddy@gmail.com', 'Customer'),
(00001018, 'Grace Miller', 'GracePass1', 'GraceM', '1994-10-17', '2109876543', '369 Cedar St, Orlando', 'grace.miller@gmail.com', 'Admin'),
(00001019, 'Ishan Choudhary', 'Ishan@123', 'IshanC', '1997-05-22', '4321098765', '147 Redwood St, Charlotte', 'ishan.choudhary@gmail.com', 'Customer'),
(00001020, 'Harper Davis', 'HarperDavis123', 'HarperD', '1996-12-08', '1098765432', '654 Maple St, Portland', 'harper.davis@gmail.com', 'Admin');


-- AccountID = CustomerID + AdminID
INSERT INTO Customer (CustomerID, CustomerPreferences, RegistrationDate, LoyaltyPoints)
VALUES
(00001005, 'Vegetarian', '2022-01-15', 150),
(00001006, 'Gluten-Free', '2022-11-30', 120),
(00001008, 'No Dietary Restrictions', '2021-07-05', 90),
(00001009, 'Lactose-Free', '2022-04-18', 130),
(00001010, 'No Red Meat', '2021-07-20', 60),
(00001012, 'No Spicy', '2021-12-10', 260),
(00001014, 'Low-Fat', '2020-09-18', 95),
(00001016, 'No Shellfish', '2022-02-25', 115),
(00001017, 'Sugar-Free', '2021-05-08', 85),
(00001019, 'Low-Sodiumg', '2020-08-05', 50);


-- User Administrator connect with Feedback; Billing Administrator connect with LogisticsInvoice
-- AccountID = CustomerID + AdminID
INSERT INTO Admin (AdminID, AdminRole, HireDate, Gender)
VALUES
(00001001, 'Super Administrator', '2020-08-05', 'Male'),
(00001002, 'Super Administrator', '2022-11-30', 'Male'),
(00001003, 'Super Administrator', '2021-05-08', 'Female'),
(00001004, 'Super Administrator', '2022-03-02', 'Female'),
(00001007, 'User Administrator', '2021-05-20', 'Female'),
(00001011, 'Billing Administrator', '2023-02-10', 'Unisex'),
(00001013, 'Billing Administrator', '2021-07-05', 'Female'),
(00001015, 'User Administrator', '2021-09-25', 'Male'),
(00001018, 'Billing Administrator', '2022-01-05', 'Male'),
(00001020, 'User Administrator', '2021-06-08', 'Unisex');


-- 1008 need 2 tables
INSERT INTO Reservation (ReservationID, CustomerID, ReservationDateAndTime, NumberOfGuests)
VALUES
(1001, 00001005, '2023-01-15 18:33:00', 4),
(1002, 00001006, '2023-03-02 19:34:00', 2),
(1003, 00001008, '2023-03-05 18:45:00', 5),
(1004, 00001016, '2023-06-11 19:23:00', 8),
(1005, 00001012, '2023-07-14 20:24:00', 4),
(1006, 00001016, '2023-09-24 13:30:00', 3),
(1007, 00001009, '2023-10-05 17:00:00', 5),
(1008, 00001012, '2023-10-20 20:23:00', 10),
(1009, 00001014, '2023-11-17 18:43:00', 4),
(1010, 00001012, '2023-11-23 19:52:00', 6);

-- ' Occupied' must have a space before occupied
INSERT INTO [Table] (TableID, TableSize, TableStatus)
VALUES
(1, 4, 'Free'),
(2, 2, 'Free'),
(3, 6, ' Occupied'),
(4, 4, 'Free'),
(5, 2, ' Occupied'),
(6, 8, 'Free'),
(7, 4, ' Occupied'),
(8, 6, 'Free'),
(9, 2, 'Free'),
(10, 4, ' Occupied');

--ReservationStatus: 1 for 'Reserved' ; 0 for 'Not Reserved'
INSERT INTO ReservedTable (ReversedTableID, TableID, ReservationID, ReservationStatus)
VALUES
(3001, 1, 1001, 1),
(3002, 2, 1002, 1),
(3003, 3, 1003, 0),
(3004, 6, 1004, 1),
(3005, 4, 1005, 1),
(3006, 5, 1006, 0),
(3007, 8, 1007, 1),
(3008, 6, 1008, 1),
(3009, 9, 1008, 1),
(3010, 9, 1009, 0),
(3011, 8, 1010, 0);


-- OrderDateAndTime must after ReservationDateAndTime in Reservation
-- OrderType = 'InHouse' must have a ReservedTable
INSERT INTO [Order] (OrderID, CustomerID, OrderDateAndTime, OrderAmount, OrderHistory, CustomOrder, OrderType)
VALUES
(2001, 00001005, '2022-08-15 12:33:00', 51, NULL, NULL, 'Online'),
(2002, 00001017, '2022-09-17 15:46:00', 73, NULL, NULL, 'Online'),
(2003, 00001017, '2022-10-23 18:40:00', 40, 2, 'Special instructions: No green onions', 'Online'),
(2004, 00001016, '2022-11-18 20:14:00', 62, NULL, 'Special instructions: No onions', 'Online'),
(2005, 00001009, '2022-12-24 12:56:00', 98, NULL, NULL, 'Online'),

(2006, 00001005, '2023-01-15 19:34:00', 55, 1, NULL, 'InHouse'),
(2007, 00001014, '2023-02-21 17:12:00', 70, NULL, 'Special instructions: Extra cheese', 'Online'),
(2008, 00001005, '2023-02-21 19:45:00', 82, 6, NULL, 'Online'),

(2009, 00001006, '2023-03-02 20:34:00', 65, NULL, NULL, 'InHouse'),

(2010, 00001008, '2023-03-05 19:23:00', 53, NULL, 'Special instructions: No tomatoes', 'InHouse'),

(2011, 00001016, '2023-06-11 21:21:00', 72, 4, NULL, 'InHouse'),
(2012, 00001009, '2023-06-26 19:20:00', 85, 5, 'Special instructions: Extra spicy', 'Online'),
(2013, 00001017, '2023-07-11 12:45:00', 56, 3, NULL, 'Online'),

(2014, 00001012, '2023-07-14 21:33:00', 66, NULL, 'Special instructions: No cheese', 'InHouse'),

(2015, 00001016, '2023-09-24 20:37:00', 73, 9, 'Special instructions: No cilantro', 'InHouse'),
(2016, 00001010, '2023-09-30 20:34:00', 92, NULL, NULL, 'Online'),
(2017, 00001019, '2023-10-01 12:32:00', 65, NULL, NULL, 'Online'),

(2018, 00001009, '2023-10-05 18:35:00', 26, 12, 'Special instructions: No mushrooms', 'InHouse'),
(2019, 00001019, '2023-10-17 17:09:00', 82, 17, NULL, 'Online'),

(2020, 00001012, '2023-10-21 16:23:00', 46, 10, NULL, 'InHouse'),
(2021, 00001008, '2023-11-05 12:34:00', 82, 20, NULL, 'Online'),

(2022, 00001014, '2023-11-18 19:43:00', 108, 7, NULL, 'InHouse'),
(2023, 00001016, '2023-11-23 18:03:00', 55, 11, NULL, 'Online'),

(2024, 00001012, '2023-11-24 19:52:00', 93, 14, 'Special instructions: No potatoes', 'InHouse'),
(2025, 00001014, '2023-11-26 12:42:00', 111, 22, NULL, 'Online');



INSERT INTO InHouse (OrderID, ReversedTableID, In_PaymentMethod, PaymentStatus, WaiterID)
VALUES
(2006, 3001, 'Cash', 'Unpaid', 'W004'),
(2009, 3002, 'Card', 'Paid', 'W009'),
(2010, 3003, 'Check', 'Unpaid', 'W010'),
(2011, 3004, 'Card', 'Paid', 'W011'),
(2014, 3005, 'Card', 'Paid', 'W013'),
(2015, 3006, 'Check', 'Paid', 'W015'),
(2018, 3007, 'Cash', 'Unpaid', 'W018'),
(2020, 3008, 'Cash', 'Unpaid', 'W020'),
(2022, 3009, 'Card', 'Paid', 'W003'),
(2024, 3010, 'Check', 'Unpaid', 'W004');



INSERT INTO OnlineOrder (OrderID, OrderStatus, Online_PaymentMethod, DriverDetails)
VALUES
(2001, 'Pending', 'Card', 'prepared'),
(2002, 'Processing', 'Apple Pay', 'Packed'),
(2003, 'Pending', 'PayPal', 'prepared'),
(2004, 'Canceled', 'Card', NULL),
(2005, 'Processing', 'Apple Pay', 'Packed'),
(2007, 'Pending', 'PayPal', 'prepared'),
(2008, 'Pending', 'Card', 'prepred'),
(2012, 'Processing', 'Apple Pay', 'Packed'),
(2013, 'Pending', 'PayPal', 'prepared'),
(2016, 'Canceled', 'Card', NULL),
(2017, 'Processing', 'Apple Pay', 'Packed'),
(2019, 'Pending', 'PayPal', 'prepared'),
(2021, 'Pending', 'Card', 'prepred'),
(2023, 'Processing', 'Apple Pay', 'Packed'),
(2025, 'Pending', 'PayPal', 'prepared');



-- both online order and in_house order could write Feedback
INSERT INTO Feedback (FeedbackID, CustomerID, AdminID, OrderID, FeedbackDate, IngredientRating, FeedbackScore, StaffRating, Suggestions)
VALUES
(4001, 1005, 1007, 2001, '2023-01-15', 'Spicy', 4, 5, 'Excellent service!'),
(4002, 1014, 1007, 2002, '2023-02-21', 'With nuts', 3, 4, 'Good experience overall.'),
(4003, 1005, 1020, 2003, '2023-02-21', 'Mild', 5, 5, 'Perfect! No suggestions.'),
(4004, 1008, 1015, 2004, '2023-03-05', 'Spicy', 2, 3, 'Delicious, but a bit slow.'),
(4005, 1017, 1015, 2005, '2023-07-11', 'With nuts', 3, 4, 'Could improve delivery time.'),
(4006, 1012, 1020, 2006, '2023-07-14', 'Mild', 5, 5, 'Fantastic! No complaints.'),
(4007, 1019, 1020, 2007, '2023-10-01', 'Spicy', 3, 3, 'Average experience.'),
(4008, 1009, 1015, 2008, '2023-10-05 ', 'Spicy', 4, 4, 'Great service.'),
(4009, 1019, 1015, 2009, '2023-10-17', 'Mild', 4, 5, 'Highly recommended.'),
(4010, 1012, 1007, 2010, '2023-10-21', 'Spicy', 2, 3, 'Food was too spicy for my liking.'),
(4011, 1008, 1007, 2013, '2023-11-05', 'Spicy', 3, 3, 'Improvement needed in packaging.'),
(4012, 1014, 1020, 2011, '2023-11-18', 'With nuts', 4, 4, 'Good job!'),
(4013, 1016, 1015, 2014, '2023-11-23', 'Mild', 4, 4, 'Timely delivery.'),
(4014, 1012, 1007, 2012, '2023-11-24', 'Mild', 5, 5, 'Perfect as always.'),
(4015, 1014, 1015, 2015, '2023-11-26', 'Mild', 5, 5, 'Slight delay in delivery.');



INSERT INTO Supplier (SupplierID, SupplierName, SupplierContactDetails, DeliverySchedule, CostAgreement)
VALUES
(5001, 'Wholefood_1', '123 Main St, Boston, MA 02108', '2023-03-01 09:00:00', 1500.00),
(5002, 'StopShop_1', '456 Pleasant St, Boston, MA 02148', '2023-03-12 10:00:00', 2000.50),
(5003, 'Costco', '789 Baker St, Boston, MA 02110', '2023-04-03 13:00:00', 8800.23),
(5004, 'Target_1', '321 Sip St, Boston, MA 02109', '2023-05-14 15:00:00', 1200.70),
(5005, 'Walmart_1', '654 Farm St, Boston, MA 02115', '2023-05-25 08:00:00', 6600.30),
(5006, 'Wholefood_2', '987 Sea St, Boston, MA 02111', '2023-06-07 11:00:00', 2200.00),
(5007, 'StopShop_2', '234 Spice St, Boston, MA 02114', '2023-06-11 14:00:00', 1950.76),
(5008, 'Walmart_2', '567 Cook St, Boston, MA 02113', '2023-07-03 16:00:00', 5350.50),
(5009, 'Target_2', '890 Organic St, Boston, MA 02112', '2023-08-14 09:00:00', 1900.25),
(5010, 'Target_3', '123 Sip St, Boston, MA 02107', '2023-10-26 12:00:00', 1550.34),
(5011, 'Walmart_3', '913 Pleasant St, Boston, MA 02115', '2023-11-13 08:00:00', 8036.00),
(5012, 'StopShop_3', '1322 Sea St, Boston, MA 02111', '2023-11-26 12:00:00', 1356.34);



-- DueDate is 20 days after the DeliverySchedule in Supplier
INSERT INTO LogisticsInvoice (InvoiceID, SupplierID, AdminID, AmountDue, DueDate, PaymentStatus)
VALUES
(6001, 5001, 1011, 1500.00, '2023-03-21', 'Paid'),
(6002, 5002, 1013, 2000.50, '2023-04-01', 'Paid'),
(6003, 5003, 1013, 8800.23, '2023-04-23', 'Overdue'),
(6004, 5004, 1018, 1200.70, '2023-06-03', 'Paid'),
(6005, 5005, 1011, 6600.30, '2023-06-14', 'Paid'),
(6006, 5006, 1011, 2200.00, '2023-06-27', 'Paid'),
(6007, 5007, 1011, 1950.76, '2023-07-01', 'Paid'),
(6008, 5008, 1018, 5350.50, '2023-07-23', 'Paid'),
(6009, 5009, 1013, 1900.25, '2023-09-03', 'Paid'),
(6010, 5010, 1018, 1550.34, '2023-11-15', 'Paid'),
(6011, 5011, 1013, 8036.00, '2023-12-03', 'Paid'),
(6012, 5012, 1018, 1356.34, '2023-12-16', 'Unpaid');


-- PaymentDate does not necessarily follow the chronological order of DueDate
-- LogisticsInvoice with no paid in PaymentStatus has no LogisticsPayment.
INSERT INTO LogisticsPayment (PaymentID, InvoiceID, PaymentDate, PaymentMethod)
VALUES
(7001, 6001, '2023-03-12', 'Bank Transfer'),
(7002, 6002, '2023-03-18', 'Check'),
(7003, 6004, '2023-05-22', 'Cash'),
(7004, 6005, '2023-06-10', 'Check'),
(7005, 6007, '2023-06-20', 'Bank Transfer'),
(7006, 6006, '2023-06-25', 'Bank Transfer'),
(7007, 6008, '2023-07-22', 'Cash'),
(7008, 6009, '2023-08-28', 'Check'),
(7009, 6010, '2023-11-05', 'Check'),
(7010, 6011, '2023-11-18', 'Bank Transfer');



INSERT INTO TransportVehicle (VehicleID, SupplierID, VehicleType, T_Capacity, CurrentLocation)
VALUES
(8001, 5001, 'Truck', 5000.00, '123 Main St, Boston, MA 02101'),
(8002, 5002, 'Van', 2500.00, '456 Arsenal St, Boston, MA 02102'),
(8003, 5003, 'Motorbike', 500.00, '789 Milk St, Boston, MA 02103'),
(8004, 5004, 'Truck', 4500.00, '321 New Salem St, Boston, MA 02104'),
(8005, 5005, 'Van', 2000.00, '654 Farm St, Boston, MA 02105'),
(8006, 5006, 'Truck', 4300.00, '987 New Salem St, Boston, MA 02106'),
(8007, 5007, 'Truck', 4800.00, '234 Arsenal St, Boston, MA 02107'),
(8008, 5008, 'Van', 2200.00, '567 Arsenal St, Boston, MA 02108'),
(8009, 5009, 'Truck', 5350.00, '890 Pleasant St, Boston, MA 02109'),
(8010, 5010, 'Truck', 5200.00, '123 New Salem St, Boston, MA 02110'),
(8011, 5011, 'Van', 2400.00, '456 Nut St, Boston, MA 02111'),
(8012, 5012, 'Motorbike', 430.00, '789 Artisan St, Boston, MA 02112'),
(8013, 5007, 'Truck', 4900.00, '321 Pleasant St, Boston, MA 02113'),
(8014, 5012, 'Van', 2100.00, '654 Arsenal St, Boston, MA 02114'),
(8015, 5011, 'Truck', 6300.00, '987 Health St, Boston, MA 02115');

INSERT INTO Warehouse (WarehouseID, SupplierID, WarehouseAddress, W_Capacity)
VALUES
(9001, 5001, '456 Arsenal St, Boston, MA 02102', 10000),
(9002, 5002, '987 Health St, Boston, MA 02115', 8000),
(9003, 5003, '234 Arsenal St, Boston, MA 02107', 12000),
(9004, 5004, '123 New Salem St, Boston, MA 02110', 9000),
(9005, 5005, '654 Farm St, Boston, MA 02105', 15000),
(9006, 5006, '890 Pleasant St, Boston, MA 02109', 6000),
(9007, 5007, '789 Artisan St, Boston, MA 02112', 10000),
(9008, 5008, '567 Cook St, Boston, MA 02108', 18000),
(9009, 5009, '123 New Salem St, Boston, MA 02110', 12000),
(9010, 5010, '987 Health St, Boston, MA 02115', 9000),
(9011, 5011, '456 Nut St, Boston, MA 02111', 15000),
(9012, 5012, '789 Artisan St, Boston, MA 02112', 16000),
(9013, 5004, '321 Pleasant St, Boston, MA 02113', 11000),
(9014, 5007, '100 Exchange St, Boston, MA 02148', 17000),
(9015, 5007, '160 Pleasant St, Boston, MA 02148', 13000);

INSERT INTO Supplier (SupplierID, SupplierName, SupplierContactDetails, DeliverySchedule, CostAgreement)
VALUES
(5001, 'Wholefood_1', '123 Main St, Boston, MA 02108', '2023-03-01 09:00:00', 1500.00),
(5002, 'StopShop_1', '456 Pleasant St, Boston, MA 02148', '2023-03-12 10:00:00', 2000.50),
(5003, 'Costco', '789 Baker St, Boston, MA 02110', '2023-04-03 13:00:00', 8800.23),
(5004, 'Target_1', '321 Sip St, Boston, MA 02109', '2023-05-14 15:00:00', 1200.70),
(5005, 'Walmart_1', '654 Farm St, Boston, MA 02115', '2023-05-25 08:00:00', 6600.30),
(5006, 'Wholefood_2', '987 Sea St, Boston, MA 02111', '2023-06-07 11:00:00', 2200.00),
(5007, 'StopShop_2', '234 Spice St, Boston, MA 02114', '2023-06-11 14:00:00', 1950.76),
(5008, 'Walmart_2', '567 Cook St, Boston, MA 02113', '2023-07-03 16:00:00', 5350.50),
(5009, 'Target_2', '890 Organic St, Boston, MA 02112', '2023-08-14 09:00:00', 1900.25),
(5010, 'Target_3', '123 Sip St, Boston, MA 02107', '2023-10-26 12:00:00', 1550.34),
(5011, 'Walmart_3', '913 Pleasant St, Boston, MA 02115', '2023-11-13 08:00:00', 8036.00),
(5012, 'StopShop_3', '1322 Sea St, Boston, MA 02111', '2023-11-26 12:00:00', 1356.34);

-- (11007, '2023-06-12', 1000, 'Broccoli, Pasta, Shrimp') send late one day than DeliverySchedule
-- (11001, '2023-03-01', 500, 'Flour, Sugar, Salt') ReceivedQuantity is less than SupplyQuantity; (13001, 10001, 5001, '2023-03-01', 550, 'Flour, Sugar, Salt'),
INSERT INTO Inventory (InventoryID, ReceivedDate, ReceivedQuantity, Received_Things)
VALUES
(11001, '2023-03-01', 500, 'Flour, Sugar, Salt'),
(11002, '2023-03-12', 300, 'Beef, Milk, Butter'),
(11003, '2023-04-03', 800, 'Chocolate, Vanilla Extract'),
(11004, '2023-05-14', 600, 'Baking Powder, Yeast, Olive Oil'),
(11005, '2023-05-25', 700, 'Tomatoes, Garlic, Onions'),
(11006, '2023-06-07', 400, 'Basil, Cheese, Chicken'),
(11007, '2023-06-12', 1000, 'Broccoli, Pasta, Shrimp'),
(11008, '2023-07-03', 200, 'Flour, Rice, Salt'),
(11009, '2023-08-14', 900, 'Eggs, Chicken, Butter'),
(11010, '2023-11-26', 1200, 'Vinegar, Pepper');



-- '2023-06-12' SupplyDate send late one day than DeliverySchedule
INSERT INTO Supplies (SuppliesID, InventoryID, SupplierID, SupplyDate, SupplyQuantity, Send_things)
VALUES
(13001, 11001, 5001, '2023-03-01', 550, 'Flour, Sugar, Salt'),
(13002, 11002, 5002, '2023-03-12', 300, 'Beef, Milk, Butter'),
(13003, 11003, 5003, '2023-04-03', 800, 'Chocolate, Vanilla Extract'),
(13004, 11004, 5004, '2023-05-14', 250, 'Baking Powder, Yeast, Olive Oil'),
(13005, 11005, 5005, '2023-05-25', 180, 'Tomatoes, Garlic, Onions'),
(13006, 11006, 5006, '2023-06-07', 400, 'Basil, Cheese, Chicken'),
(13007, 11007, 5007, '2023-06-12', 1000, 'Broccoli, Pasta, Shrimp'),
(13008, 11008, 5008, '2023-07-03', 200, 'Flour, Rice, Salt'),
(13009, 11009, 5009, '2023-08-14', 900, 'Eggs, Chicken, Butter'),
(13010, 11010, 5010, '2023-11-26', 1200, 'Vinegar, Pepper');




-- IngredientID in range(12011,12015) has the same IngredientName before
-- milk: one month; flour: 2; sugar:2; butter: 3; salt: 6; chicken,beef,Tomatoes,Broccoli,eggs 1;
INSERT INTO Ingredient (IngredientID, InventoryID, IngredientName,  IngredientQuantity, ExpiryDate)
VALUES
  (12001, 11001,'Flour',  200, '2023-05-01'),
  (12002, 11001,'Sugar',  100, '2023-05-01'),
  (12003, 11009,'Eggs',  50, '2023-09-14'),
  (12004, 11002,'Milk',  50, '2023-04-12'),
  (12005, 11002,'Butter',  100, '2023-06-12'),
  (12006, 11001,'Salt',  200, '2023-09-01'),
  (12007, 11010,'Pepper',  150, '2024-11-26'),
  (12008, 11006,'Chicken',  300, '2023-07-07'),
  (12009, 11002,'Beef',  150, '2023-04-12'),
  (12010, 11005,'Tomatoes', 100, '2023-06-25'),
  (12011, 11008,'Flour', 50, '2023-07-03'),
  (12012, 11009,'Butter', 100, '2023-11-14'),
  (12013, 11008,'Rice', 100, '2024-01-03'),
  (12014, 11007,'Broccoli', 300, '2023-07-12'),
  (12015, 11009,'Chicken', 500, '2023-09-14');



INSERT INTO MenuItems (MenuItemID, ItemName, Price, Popularity)
VALUES
(15001, 'Margherita Pizza', 10.99, 180),
(15002, 'Caesar Salad', 8.99, 200),
(15003, 'Vegetarian Stir-Fry', 11.99, 130),
(15004, 'Cheeseburger', 9.99, 220),
(15005, 'Chicken Caesar Wrap', 7.99, 190),
(15006, 'Mushroom Risotto', 13.99, 110),
(15007, 'Classic Tiramisu', 6.99, 250),
(15008, 'Club Sandwich', 9.49, 200),
(15009, 'Shrimp Scampi', 15.99, 90),
(15010, 'Beef Stir-Fry', 14.49, 130);



INSERT INTO MenuItemIngredient (MenuItemID, IngredientID, QuantityRequired)
VALUES
(15001, 12001, 2.5),
(15001, 12002, 1.5),
(15002, 12006, 0.5),
(15003, 12010, 1.5),
(15004, 12009, 1.5),
(15004, 12005, 1.1),
(15005, 12008, 1.0),
(15006, 12012, 1.0),
(15007, 12011, 0.5),
(15007, 12002, 1.0),
(15008, 12014, 0.8),
(15008, 12015, 1.2),
(15008, 12011, 1.0),
(15010, 12009, 0.5);



































