-- 1. Stored Procedures
-- (1) GetCustomerDetails: Getting information about customers
CREATE PROCEDURE GetCustomerDetails
    @CustomerID INT,
    @CustomerName VARCHAR(50) OUTPUT,
    @RegistrationDate DATE OUTPUT,
    @LoyaltyPoints INT OUTPUT
AS
BEGIN
    DECLARE @Name VARCHAR(50);
    SELECT @Name = UA.AccountName, @RegistrationDate = C.RegistrationDate, @LoyaltyPoints = C.LoyaltyPoints
    FROM Customer C
    JOIN UserAccount UA ON C.CustomerID = UA.AccountID
    WHERE C.CustomerID = @CustomerID;
    SET @CustomerName = @Name;
END;


DECLARE @CustomerNameResult VARCHAR(50);
DECLARE @RegistrationDateResult DATE;
DECLARE @LoyaltyPointsResult INT;
EXEC GetCustomerDetails
    @CustomerID = 00001017,
    @CustomerName = @CustomerNameResult OUTPUT,
    @RegistrationDate = @RegistrationDateResult OUTPUT,
    @LoyaltyPoints = @LoyaltyPointsResult OUTPUT;
PRINT 'Customer Name: ' + @CustomerNameResult + ' ' + ' ' + CAST(@LoyaltyPointsResult AS VARCHAR)
PRINT 'RegistrationD Date: ' + CONVERT(VARCHAR, @RegistrationDateResult, 120); 
PRINT 'Customer Loyalty-Points: ' + CAST(@LoyaltyPointsResult AS VARCHAR);


-- (2) GetReservedTableStatus: Get the status of the table booked by this customer
CREATE PROCEDURE GetReservedTableStatus
    @CustomerID INT,
    @TableStatus VARCHAR(25) OUTPUT
AS
BEGIN
    DECLARE @Status VARCHAR(25);
    SELECT @Status = T.TableStatus
    FROM Customer C
		JOIN Reservation R ON C.CustomerID = R.CustomerID
		JOIN ReservedTable RT ON RT.ReservationID = R.ReservationID
    JOIN [Table] T ON RT.TableID = T.TableID
    WHERE C.CustomerID = @CustomerID;
    SET @TableStatus = @Status;
END;



DECLARE @TableStatusResult VARCHAR(25);
EXEC GetReservedTableStatus
    @CustomerID = 1005,
    @TableStatus = @TableStatusResult OUTPUT;
PRINT ' Table Status Result: ' + @TableStatusResult


-- (3) SearchDishesByIngredient: Search for dishes based on included ingredients
CREATE PROCEDURE SearchDishesByIngredient
    @IngredientName VARCHAR(50),
    @DishList VARCHAR(MAX) OUTPUT
AS
BEGIN
    SET @DishList = '';
    SELECT @DishList += MI.ItemName + ', '
    FROM MenuItems MI
    JOIN MenuItemIngredient MII ON MI.MenuItemID = MII.MenuItemID
    JOIN Ingredient I ON MII.IngredientID = I.IngredientID
    WHERE I.IngredientName LIKE '%' + @IngredientName + '%';
    SET @DishList = LEFT(@DishList, LEN(@DishList) - 1);
END;


DECLARE @ResultDishes VARCHAR(MAX);
EXEC SearchDishesByIngredient @IngredientName = 'Butter', @DishList = @ResultDishes OUTPUT;
PRINT 'Dishes that contain this ingredient are: ' + @ResultDishes;





-- 2. VIEWS
-- (1) This view gives a report about Providing details of each order, 
--		including the customer details, order details, and reservation details.
CREATE VIEW CustomerOrderView AS
SELECT
    O.OrderID,
    U.UserName AS CustomerName,
    O.OrderDateAndTime,
    O.OrderAmount,
    O.OrderType,
    R.ReservationDateAndTime
FROM
    [Order] O
    LEFT JOIN Customer C ON O.CustomerID = C.CustomerID
    JOIN UserAccount U ON C.CustomerID = U.AccountID
    LEFT JOIN Reservation R ON O.CustomerID = R.CustomerID AND O.OrderType = 'InHouse';
		
SELECT *
FROM CustomerOrderView;


-- (2)This view provides a report on the planned delivery date, quality, items, 
-- 		and the actual date, quality, and content received by the restaurant
-- 		Find the ones in which the SupplyQuantity in SUPPLIES is different from the ReceivedQuantity in INVENTORY
CREATE VIEW SupplierInventoryView AS
SELECT
    S.SupplierName,
    S.DeliverySchedule,
		SU.SupplyQuantity,
		I.InventoryID,
    I.ReceivedDate,
    I.Received_Things,
    I.ReceivedQuantity,
    I.Received_Things AS InventoryName
FROM
    Supplier S
    JOIN Supplies SU ON S.SupplierID = SU.SupplierID
    JOIN Inventory I ON SU.InventoryID = I.InventoryID
WHERE SU.SupplyQuantity != I.ReceivedQuantity;

SELECT *
FROM SupplierInventoryView;



-- (3) This view provides a report of unpaid or overdue Supplier
CREATE VIEW SupplierPerformanceView AS
SELECT
    S.SupplierID,
    S.SupplierName,
    LI.InvoiceID,
    LI.AmountDue,
    LI.DueDate,
    LI.PaymentStatus,
    LP.PaymentID,
    LP.PaymentDate,
    LP.PaymentMethod
FROM
    Supplier S
    LEFT JOIN LogisticsInvoice LI ON S.SupplierID = LI.SupplierID
    LEFT JOIN LogisticsPayment LP ON LI.InvoiceID = LP.InvoiceID
WHERE
    LI.PaymentStatus = 'Overdue' OR  LI.PaymentStatus = 'Unpaid';
		
SELECT *
FROM SupplierPerformanceView;



-- 3. Create a trigger that updates LoyaltyPoints in Customer table after each order
CREATE TRIGGER UpdateCustomerLoyaltyPoints
ON [Order]
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Customer
    SET LoyaltyPoints = LoyaltyPoints + 
        CASE
            WHEN i.OrderAmount >= 50 THEN 5   
            WHEN i.OrderAmount >= 30 THEN 3   
            ELSE 1                           
        END
    FROM Customer C
    INNER JOIN inserted i ON C.CustomerID = i.CustomerID;
END;

INSERT INTO [Order]
	VALUES (2026, 00001014, '2023-11-28 12:00:00', 37, 25, NULL, 'Online');


-- 4. Table-level CHECK Constraints
/*
We have created  table level check constraints during table creations. The details are as follows -
(1) TABLE UserAccount 	-- AccountType Column 			-- IN ('Customer', 'Admin')
(2) TABLE ReservedTable -- ReservationStatus Column -- IN (1, 0)
(3) TABLE [Table]				-- TableStatus COLUMN				-- IN ('Free', 'Occupied')
(4) TABLE [Order]				-- OrderType COLUMN					-- IN ('InHouse', 'Online')
(5) TABLE InHouse 			-- In_PaymentMethod COLUMN	-- IN ('Card', 'Cash', 'Check')
(6) TABLE InHouse 			-- PaymentStatus COLUMN			-- IN ('Paid', 'Unpaid')
(7) TABLE OnlineOrder 	-- OrderStatus COLUMN				-- IN ('Pending', 'Processing', 'Canceled')
(8) TABLE OnlineOrder		-- Online_PaymentMethod COLUMN   	-- IN ('Card', 'Apple Pay', 'PayPal')
(9) TABLE OnlineOrder 	-- DriverDetails COLUMN			-- IN ('prepred', 'Packed', 'delivered',NULL)
(10) TABLE Admin				-- AdminRole COLUMN					-- IN ('Super Administrator', 'Billing Administrator', 'User Administrator')
(11) TABLE Admin				-- Gender COLUMN						-- IN ('Female', 'Male', 'Unisex')
(12) TABLE LogisticsInvoice 	-- PaymentStatus COLUMN 		--IN ('Paid', 'Unpaid', 'Overdue')
(13) TABLE LogisticsPayment 	-- PaymentMethod COLUMN			-- IN  ('Bank Transfer', 'Card', 'Cash', 'Check')
(14) TABLE TransportVehicle 	-- VehicleType COLUMN				-- IN  ('Truck', 'Van', 'Motorbike')
*/

-- 5. Computed Columns based on a user defined function (UDF)
-- Calculate the total order amount (Tax: 6.25%)
CREATE FUNCTION dbo.CalculateDiscountAndTotalAmount (@OrderAmount INT)
RETURNS DECIMAL(5, 2)
AS
BEGIN
    DECLARE @TotalAmount DECIMAL(5, 2);
    SET @TotalAmount = @OrderAmount * 1.0625;
    RETURN @TotalAmount;
END;


ALTER TABLE [Order]
 ADD Total_Amount AS dbo.CalculateDiscountAndTotalAmount(OrderAmount);


-- 6. Column Data Encryption
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Group11_11_28';
SELECT name KeyName, 
    symmetric_key_id KeyID, 
    key_length KeyLength, 
    algorithm_desc KeyAlgorithm
FROM sys.symmetric_keys;

GO
CREATE CERTIFICATE DataProtect WITH SUBJECT = 'Protect Restaraunt Data';

GO
SELECT name CertName, 
    certificate_id CertID, 
    pvt_key_encryption_type_desc EncryptType, 
    issuer_name Issuer
FROM sys.certificates;

CREATE SYMMETRIC KEY DataProtect_test WITH ALGORITHM = AES_256 ENCRYPTION BY CERTIFICATE DataProtect;

SELECT name KeyName, 
    symmetric_key_id KeyID, 
    key_length KeyLength, 
    algorithm_desc KeyAlgorithm
FROM sys.symmetric_keys;

-- (1) Password IN UserAccount 
ALTER TABLE UserAccount 
ADD Password_encryption varbinary(MAX)

OPEN SYMMETRIC KEY DataProtect_test
DECRYPTION BY CERTIFICATE DataProtect;	
							
UPDATE UserAccount
SET Password_encryption = EncryptByKey (Key_GUID('DataProtect_test'), AccountPassword)
FROM UserAccount;
GO

CLOSE SYMMETRIC KEY DataProtect_test;

Select * FROM UserAccount;

-- (2) LoyaltyPoints IN Customer
ALTER TABLE Customer 
ADD LoyaltyPoints_encryption varbinary(MAX)

OPEN SYMMETRIC KEY DataProtect_test
DECRYPTION BY CERTIFICATE DataProtect;	

UPDATE Customer         
SET LoyaltyPoints_encryption = EncryptByKey (Key_GUID('DataProtect_test'), STR(LoyaltyPoints))        
FROM Customer;
GO

CLOSE SYMMETRIC KEY DataProtect_test;

SELECT * FROM Customer;




-- 7. 3 non-clustered indexes
-- (1)Index 1: Index_CustomerID_Customer
-- Purpose: Improve performance on CustomerID in the Customer table 
CREATE NONCLUSTERED INDEX Index_CustomerID_Customer 
ON Customer (CustomerID); 

SELECT *
FROM [Order]
ORDER BY CustomerID;



-- (2)Index 2: Index_OrderDateAndTime_Order 
-- Purpose: Improve performance on OrderDateAndTime in the Order table 
CREATE NONCLUSTERED INDEX Index_OrderDateAndTime_Order 
ON [Order] (OrderDateAndTime); 


-- (3)Index 3: IX_Ingredient_IngredientName
-- Purpose: Improve performance on IngredientName in the Order Ingredient 
CREATE INDEX IX_Ingredient_IngredientName
ON Ingredient (IngredientName);

SELECT *
FROM MenuItemIngredient
INNER JOIN Ingredient ON MenuItemIngredient.IngredientID = Ingredient.IngredientID
WHERE Ingredient.IngredientName = 'Butter';



