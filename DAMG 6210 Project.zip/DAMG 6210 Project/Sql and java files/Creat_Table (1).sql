-- Create the database
--CREATE DATABASE RestaurantManagementSystem;

USE RestaurantManagementSystem;

-- UserAccount TABLE
-- AccountID = CustomerID + AdminID
CREATE TABLE UserAccount (
   AccountID INT PRIMARY KEY NOT NULL,
   AccountName VARCHAR(50) NOT NULL,
   AccountPassword VARCHAR(50) NOT NULL,
   UserName VARCHAR(25) NOT NULL,
   UserDateOfBirth DATE,
   UserContactNumber VARCHAR(15),
   UserAddress VARCHAR(255),
   UserEmail VARCHAR(255),
   AccountType VARCHAR(50) NOT NULL,
	 CONSTRAINT AccountType_CHK CHECK (AccountType IN ('Customer', 'Admin'))
);


-- Customer TABLE
-- CustomerPreferences: Vegan, vegetarian....
CREATE TABLE Customer (
   CustomerID INT PRIMARY KEY NOT NULL,
   CustomerPreferences VARCHAR(50),
   RegistrationDate DATE,
   LoyaltyPoints INT,
	 FOREIGN KEY (CustomerID) REFERENCES UserAccount(AccountID)
);


-- Reservation TABLE
CREATE TABLE Reservation (
   ReservationID INT PRIMARY KEY NOT NULL,
   CustomerID INT,
   ReservationDateAndTime DATETIME,
	 NumberOfGuests INT,
   FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);


-- TABLE ReservedTable
CREATE TABLE ReservedTable(
	ReversedTableID INT PRIMARY KEY NOT NULL,
	TableID INT,
	ReservationID INT,
	ReservationStatus INT,
	CONSTRAINT ReservationStatus_CHK CHECK (ReservationStatus IN (1, 0)),
	FOREIGN KEY (TableID) REFERENCES [Table](TableID),
	FOREIGN KEY (ReservationID) REFERENCES Reservation(ReservationID)
);


-- Table TABLE
--- one reservation could book more than one table
CREATE TABLE [Table] (
   TableID INT PRIMARY KEY NOT NULL,
   TableSize INT,
   TableStatus VARCHAR(25),
	 CONSTRAINT TableStatus_CHK CHECK (TableStatus IN ('Free', 'Occupied'))
);



-- Order TABLE
-- OrderAmount: total price 
-- OrderHistory: what they CREATE brfore(brfore OrderID)
-- CustomOrder: special request
CREATE TABLE [Order] (
   OrderID INT PRIMARY KEY NOT NULL,
   CustomerID INT,
   OrderDateAndTime DATETIME,
   OrderAmount INT,
	 OrderHistory INT,
   CustomOrder VARCHAR(255),
	 OrderType VARCHAR(25),
   FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
	 CONSTRAINT OrderType_CHK CHECK (OrderType IN ('InHouse', 'Online'))
);


-- Inhouse TABLE
CREATE TABLE InHouse (
	OrderID INT PRIMARY KEY NOT NULL,
	ReversedTableID INT,
	In_PaymentMethod VARCHAR(25),
	PaymentStatus VARCHAR(25),
	WaiterID VARCHAR(25),
	FOREIGN KEY (ReversedTableID) REFERENCES ReservedTable(ReversedTableID),
	FOREIGN KEY (OrderID) REFERENCES [Order](OrderID),
	CONSTRAINT I_In_PaymentMethod_CHK CHECK (In_PaymentMethod IN ('Card', 'Cash', 'Check')),
	CONSTRAINT PaymentStatus_CHK CHECK (PaymentStatus IN ('Paid', 'Unpaid'))
);


-- Online TABLE
CREATE TABLE OnlineOrder(
	OrderID INT PRIMARY KEY NOT NULL,
	OrderStatus VARCHAR(25),
	Online_PaymentMethod VARCHAR(25),
	DriverDetails VARCHAR(25),
	FOREIGN KEY (OrderID) REFERENCES [Order](OrderID),
	CONSTRAINT O_OrderStatus_CHK CHECK (OrderStatus IN ('Pending', 'Processing', 'Canceled')),
	CONSTRAINT O_Online_PaymentMethod_CHK CHECK (Online_PaymentMethod IN ('Card', 'Apple Pay', 'PayPal')),
	CONSTRAINT DriverDetails_CHK CHECK (DriverDetails IN ('prepred', 'Packed', 'delivered',NULL))
);

-- FeedBack TABLE
-- IngredientRating: spicy, with nuts......
CREATE TABLE Feedback (
   FeedbackID INT PRIMARY KEY NOT NULL,
   CustomerID INT,
	 AdminID INT,
	 OrderID INT,
   FeedbackDate DATE,
   IngredientRating VARCHAR(255),
   FeedbackScore INT,
   StaffRating INT,
   Suggestions VARCHAR(255),
   FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
	 FOREIGN KEY (AdminID) REFERENCES Admin(AdminID),
	 FOREIGN KEY (OrderID) REFERENCES [Order](OrderID)
);



-- Admin TABLE
CREATE TABLE Admin (
   AdminID INT PRIMARY KEY NOT NULL,
   AdminRole VARCHAR(255),
   HireDate DATE,
	 Gender VARCHAR(25),
	 FOREIGN KEY (AdminID) REFERENCES UserAccount(AccountID),
   CONSTRAINT AdminRole_CHK CHECK (AdminRole IN ('Super Administrator', 'Billing Administrator', 'User Administrator')),
	 CONSTRAINT Gender_CHK CHECK (Gender IN ('Female', 'Male', 'Unisex'))
);


-- LogisticsInvoice TABLE
CREATE TABLE LogisticsInvoice (
   InvoiceID INT PRIMARY KEY NOT NULL,
   SupplierID INT,
	 AdminID INT,
   AmountDue FLOAT,
   DueDate DATE,
   PaymentStatus VARCHAR(25),
   FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID),
	 FOREIGN KEY (AdminID) REFERENCES Admin(AdminID),
   CONSTRAINT L_PaymentStatus_CHK CHECK (PaymentStatus IN ('Paid', 'Unpaid', 'Overdue'))
);


-- LogisticsPayment TABLE
CREATE TABLE LogisticsPayment (
   PaymentID INT PRIMARY KEY NOT NULL,
   InvoiceID INT,
   PaymentDate DATE,
   PaymentMethod VARCHAR(25),
   FOREIGN KEY (InvoiceID) REFERENCES LogisticsInvoice(InvoiceID),
   CONSTRAINT L_PaymentMethod_CHK CHECK (  PaymentMethod IN  ('Bank Transfer', 'Card', 'Cash', 'Check')),
);

-- Supplier TABLE
CREATE TABLE Supplier (
   SupplierID INT PRIMARY KEY NOT NULL,
   SupplierName VARCHAR(50),
   SupplierContactDetails VARCHAR(255),
   DeliverySchedule DATETIME,
   CostAgreement FLOAT
);

-- TransportVehicle TABLE
CREATE TABLE TransportVehicle (
   VehicleID INT PRIMARY KEY NOT NULL,
   SupplierID INT,
   VehicleType VARCHAR(25),
   T_Capacity FLOAT,
	 CurrentLocation VARCHAR(255),
   FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID),
   CONSTRAINT VehicleType_CHK CHECK (  VehicleType IN  ('Truck', 'Van', 'Motorbike'))
);

-- WAREHOUSE TABLE
CREATE TABLE Warehouse (
   WarehouseID INT PRIMARY KEY NOT NULL,
   SupplierID INT,
   WarehouseAddress VARCHAR(255),
   W_Capacity INT,
   FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID)
);


-- Supplies TABLE
CREATE TABLE Supplies (
   SuppliesID INT PRIMARY KEY NOT NULL,
   InventoryID INT,
   SupplierID INT,
	 SupplyDate DATE,
   SupplyQuantity INT,
   Send_things VARCHAR(255),
   FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID),
	 FOREIGN KEY (InventoryID) REFERENCES Inventory(InventoryID),
);


-- inventory TABLE
CREATE TABLE Inventory (
   InventoryID INT PRIMARY KEY NOT NULL,
   ReceivedDate DATE,
   ReceivedQuantity INT,
   Received_Things VARCHAR(255)
);

-- Ingredients TABLE
CREATE TABLE Ingredient (
   IngredientID INT PRIMARY KEY NOT NULL,
	 InventoryID INT,
   IngredientName VARCHAR(255),
   IngredientQuantity INT,
   ExpiryDate DATE,
	 FOREIGN KEY (InventoryID) REFERENCES Inventory(InventoryID),
);



-- MenuItemIngredient TABLE
CREATE TABLE MenuItemIngredient (
   MenuItemID INT NOT NULL,
   IngredientID INT NOT NULL,
   QuantityRequired FLOAT,
	 PRIMARY KEY (MenuItemID, IngredientID),
   FOREIGN KEY (MenuItemID) REFERENCES MenuItems(MenuItemID),
	 FOREIGN KEY (IngredientID) REFERENCES Ingredient(IngredientID)
);



-- Menuitems TABLE
CREATE TABLE MenuItems (
   MenuItemID INT PRIMARY KEY NOT NULL,
   ItemName VARCHAR(50),
   Price DECIMAL(10, 2),
   Popularity INT
);

























